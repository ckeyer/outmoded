﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Xml;


namespace CHCJ
{
	class CJConfig
    {
        private const string confPath = "../../config/connect_conf.xml";
        public const string XMLHeader = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";

        public const int max_context_bytes = 2048;
        private int timeout = 5000;   // 重传间隔时间
        private int max_repeat_times = 3;   // 最大重传次数

        private UdpClient udpServer;    // 用于监听接收收据
        public IPEndPoint server_end_point = 
            new IPEndPoint(IPAddress.Parse("127.0.0.1"),2222);

        private UdpClient udpLocal;     // 用于发送数据
        private int local_port = 2222;

        public enum ConfigState
        {
            OK = 0,     // 发送成功，并收到回复
            DEFAULT,  // 有错误，而且已经使用默认值
            WARING,    // 警告
            ERROR    // 严重错误
        }

        private ConfigState getConf()
        {
            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                xmlDoc.Load(confPath);
            }
            catch
            {
                ConfigState cstmp = initConfFile()
                if (cstmp > ConfigState.WARING)
                {
                    return cstmp;
                }
                xmlDoc.LoadXml(confPath);
            }
            try
            {
                XmlElement rootNode = xmlDoc.DocumentElement;
                XmlNode node;
                node = rootNode.SelectSingleNode("Config");
                foreach (XmlNode userNode in node.SelectNodes("Server"))
                {
                    IPAddress ip = IPAddress.Parse(userNode.SelectSingleNode("IPAddress").InnerText);
                    int port = int.Parse(userNode.SelectSingleNode("Port").InnerText);
                    server_end_point = new IPEndPoint(ip, port);
                    timeout = int.Parse(userNode.SelectSingleNode("TimeOut").InnerText);
                    max_repeat_times = int.Parse(userNode.SelectSingleNode("MaxRepeatTimes").InnerText);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("读取链接配置文件出现错误");
                server_end_point = new IPEndPoint(IPAddress.Parse(""), 2222);
                return ConfigState.DEFAULT;
                //System.Environment.Exit(-1);
            }
            return ConfigState.OK;
        }

        private ConfigState initConfFile()
        {
            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                string xmlFrame = @"
<cjstudio>
  <Project>
    <Name>CHCJ</Name>
    <Version>v1.0</Version>
    <Author>CJ_Studio</Author>
    <CreateTime>2014-5-7 下午</CreateTime>
    <UpdateTime>2014-5-11 下午</UpdateTime>
  </Project>
 <Config>
    <Server>
      <IPAddress>127.0.0.1</IPAddress>
      <Port>2222</Port>
      <TimeOut>5000</TimeOut>
      <MaxRepeatTimes>3</MaxRepeatTimes>
    </Server>
  </Config>
</cjstudio>";
                xmlDoc.LoadXml(XMLHeader + xmlFrame);

                XmlElement rootNode = xmlDoc.DocumentElement;
                rootNode.SetAttribute("name", "connect.conf");
                xmlDoc.Save(confPath);
            }
            catch (Exception)
            {
                // MessageBox.Show("初始化链接配置文件出错，可能需要重新安装");
                return ConfigState.ERROR;
            }
            return ConfigState.OK;
        }
	}
}

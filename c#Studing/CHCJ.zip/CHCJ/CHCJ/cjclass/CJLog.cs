﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace CHCJ
{
    class CJLog
    {
        private string log_file_path = "../../user/my.log";
        private FileStream fs;
        public LogLevel level = LogLevel.DEFAULT;
        public LogModel model = LogModel.MESSAGE_BOX_SHOW;
        private TextBox text_box;
        private ListBox list_box;
        public bool auto_datetime = true;

        delegate void CallBackLogControl(string str);
        CallBackLogControl cbLogControl;

        public enum LogLevel : uint
        {
            FATAL_ERROR = 0,     // 严重错误
            COMMON_ERROR,   // 一般性错误
            WARING,     // 警告性信息
            DEFAULT,    // 默认级别
            DEBUG,   // 调试
            ALL
        }

        public enum LogModel : uint
        {
            NONE = 0,
            LOG_FILE=1,     // 写入日志文件
            MESSAGE_BOX_SHOW=2,     // 消息框弹出
            TEXT_BOX_SHOW=4,    // TextBox 显示
            LIST_BOX_SHOW = 8     // ListBox 显示
        }

        CJLog()
        {
            fs = new FileStream(log_file_path, FileMode.OpenOrCreate);
        }

        CJLog(string log_path)
        {
            setLogFilePath(log_path);
            model |= LogModel.LOG_FILE;
        }

        CJLog(LogLevel lev,LogModel mod,string log_path)
        {
            setLogLevel(lev);
            setLogModel(mod);
            setLogFilePath(log_path);
            model |= LogModel.LOG_FILE;
        }

        CJLog(LogLevel lev, LogModel mod)
        {
            setLogLevel(lev);
            setLogModel(mod);
        }

        CJLog(LogLevel lev, LogModel mod,Control cont)
        {
            setLogLevel(lev);
            setLogModel(mod);
            setControl(cont);
        }

        public void setControl(Control con)
        {
            if (con.GetType().ToString() == "System.Windows.Forms.ListBox")
            {
                list_box = (ListBox)con;
                cbLogControl = new CallBackLogControl(setListboxText);
            }
            else
            {
                text_box = (TextBox)con;
                cbLogControl = new CallBackLogControl(setTextboxText);
            }
        }

        public void setLogFilePath(string path)
        {
            if (fs != null)
            {
                fs.Close();
            }
            try
            {
                fs = new FileStream(path, FileMode.OpenOrCreate);
                log_file_path = path;                
            }
            catch (Exception)
            {
                MessageBox.Show("日志文件配置错误", "CJ_Studio");
                fs = new FileStream(log_file_path, FileMode.OpenOrCreate);
                
            }
        }

        public void setLogModel(LogModel mod)
        {
            model = mod;
        }

        public void addLogModel(LogModel mod)
        {
            model |= mod;
        }

        public void setLogLevel(LogLevel lev)
        {
            level = lev;
        }

        public void loging(string str)
        {
            str = formatStr(str);
            if ((model & LogModel.LOG_FILE) != 0)
            {
                loging_logfile(str);
            } 
            if ((model & LogModel.LIST_BOX_SHOW) != 0)
            {
                loging_listbox(str);
            }
            if ((model & LogModel.TEXT_BOX_SHOW) != 0)
            {
                loging_textbox(str);
            }
            if ((model & LogModel.MESSAGE_BOX_SHOW) != 0)
            {
                loging_messagebox(str);
            }
        }

        public void loging(string str, LogLevel lev)
        {
            if (lev <= level)
                loging(str);
        }

        private void loging_messagebox(string str)
        {
            MessageBox.Show(str,"CJ_Studio");
        }

        private void loging_textbox(string str)
        {
            text_box.Invoke(cbLogControl,str);
        }

        private void loging_listbox(string str)
        {
            list_box.Invoke(cbLogControl,str);
        }

        private void loging_logfile(string str)
        {
            ;
        }

        private string formatStr(string str)
        {
            if (!auto_datetime)
                return str;

            return string.Format("[{0}]: {1}", DateTime.Now.ToString(),str);
        }

        private void setTextboxText(string str)
        {
            text_box.Text += str;
            text_box.Text += "\r\n";
            text_box.SelectionStart = text_box.Text.Length - 1;
            text_box.ScrollToCaret();
        }

        private void setListboxText(string str)
        {
            list_box.Items.Add(str);
            list_box.SelectedIndex = list_box.Items.Count - 1;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace CHCJ
{
    public partial class LoginForm : Form
    {
        public const string imgDir = "../../resource/img/";
        public const string icoDir = "../../resource/ico/";
        public const string confPath = "../../config/loginForm_conf.xml";
        public const string XMLHeader = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";
        
        private Point mouse_sub_form;
        private List<LocalUser> localUsers = new List<LocalUser>();
       
        public LoginForm()
        {
            InitializeComponent();
        }

        private void initConfLocal()
        {
            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                string xmlFrame = @"
<cjstudio>
  <Project>
    <Name>CHCJ</Name>
    <Version>v1.0</Version>
    <Author>CJ_Studio</Author>
    <CreateTime>2014-5-7 下午</CreateTime>
    <UpdateTime>2014-5-11 下午</UpdateTime>
  </Project>
  <Config>
    <UserList>
    </UserList>
  </Config>
</cjstudio>";
                xmlDoc.LoadXml(XMLHeader + xmlFrame);

                XmlElement rootNode = xmlDoc.DocumentElement;
                rootNode.SetAttribute("name", "loginFrom.conf");
                xmlDoc.Save(confPath);
            }
            catch (Exception)
            {
                MessageBox.Show("初始化配置文件出错，可能需要重新安装");
                System.Environment.Exit(-1);
            }
        }

        private void getConfLocal()
        {
            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                xmlDoc.Load(confPath);
            }
            catch
            {
                initConfLocal();
                xmlDoc.LoadXml(confPath);
            }
            try
            {
                XmlElement rootNode = xmlDoc.DocumentElement;
                XmlNode node;
                node = rootNode.SelectSingleNode("Config").SelectSingleNode("UserList");
                foreach(XmlNode userNode in node.SelectNodes("User"))
                {
                    LocalUser user = new LocalUser();
                    user.userID = userNode.SelectSingleNode("UserID").InnerText;
                    user.userName = userNode.SelectSingleNode("Name").InnerText;
                    user.password = userNode.SelectSingleNode("Password").InnerText;
                    if(userNode.SelectSingleNode("IsAutoLogin").InnerText=="Y")
                    {
                        user.is_auto_login = true;
                    }
                    else
                    {
                        user.is_auto_login = false;
                    }
                    if(userNode.SelectSingleNode("IsRemPasswd").InnerText=="Y")
                    {
                        user.is_rem_passwd = true;
                    }
                    else
                    {
                        user.is_rem_passwd =false;
                    }
                    user.last_login_time_string = userNode.SelectSingleNode("LastLoginTime").InnerText;
                    user.last_login_time = DateTime.Parse(user.last_login_time_string);
                    localUsers.Add(user);
                }
                localUsers.Sort(LocalUser.CompareByDate);
            }
            catch (Exception)
            {
                ;
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            notifyIcon1.Icon = new Icon(icoDir + "mine.ico");

            this.BackgroundImageLayout = ImageLayout.Stretch;
            this.BackgroundImage = Image.FromFile(imgDir + "login_bg.jpg");
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Image.FromFile(imgDir + "close.png");
            pictureBox2.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox2.BackgroundImage = Image.FromFile(icoDir + "mine.ico");
            pictureBox3.BackColor = Color.Transparent;
            pictureBox3.Image = Image.FromFile(imgDir + "minForm.png");
            getConfLocal();
            foreach (LocalUser user in localUsers)
            {
                if (user.userID == localUsers[0].userID)
                {
                    comboBox1.Text = user.userID;
                }
                comboBox1.Items.Add(user.userID);
                
            }
            timer_loading.Start();
        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(imgDir + "closing.png");
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(imgDir + "close.png");
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            pictureBox1.Image = Image.FromFile(imgDir + "close.png");
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            pictureBox1.Image = Image.FromFile(imgDir + "closing.png");
            notifyIcon1.Dispose();
            System.Environment.Exit(0);
        }

        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            pictureBox3.Image = Image.FromFile(imgDir + "minForm.png");
        }

        private void pictureBox3_MouseEnter(object sender, EventArgs e)
        {
            pictureBox3.Image = Image.FromFile(imgDir + "minFroming.png");
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.Image = Image.FromFile(imgDir + "minForm.png");
        }

        private void pictureBox3_MouseUp(object sender, MouseEventArgs e)
        {
            pictureBox3.Image = Image.FromFile(imgDir + "minFroming.png");
            this.Visible = false;
        }

        private void timer_loading_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >= 1.0)
            {
                timer_loading.Stop();
            }
            else
            {
                this.Opacity += .1;
            }
        }

        private void LoginForm_MouseDown(object sender, MouseEventArgs e)
        {
            mouse_sub_form.X = e.X;
            mouse_sub_form.Y = e.Y;
            timer_moving_from.Start();
        }

        private void LoginForm_MouseUp(object sender, MouseEventArgs e)
        {
            timer_moving_from.Stop();
        }

        private void timer_moving_from_Tick(object sender, EventArgs e)
        {
            this.Location = new Point(Control.MousePosition.X - mouse_sub_form.X,
                Control.MousePosition.Y - mouse_sub_form.Y);
        }

        private void notifyIcon1_MouseUp(object sender, MouseEventArgs e)
        {
            this.Visible = !this.Visible;
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            string userid = comboBox1.Text;
            textBox2.Clear();
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            foreach (LocalUser user in localUsers)
            {
                if (userid == user.userID)
                {
                    if (user.is_auto_login)
                    {
                        textBox2.Text = user.password;
                        checkBox1.Checked = true;
                        checkBox2.Checked = true;
                        break;
                    }
                    if (user.is_rem_passwd)
                    {
                        textBox2.Text = user.password;
                        checkBox2.Checked = true;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ;
            //Application.Run(new MainForm());
        }
 
    }
}

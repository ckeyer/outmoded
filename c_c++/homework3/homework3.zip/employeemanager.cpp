#include "employeemanager.h"

EmployeeManager::EmployeeManager()
{
}

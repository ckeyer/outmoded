#ifndef EMPLOYEEMANAGER_H
#define EMPLOYEEMANAGER_H

class EmployeeManager
{
public:
    EmployeeManager();
};

#endif // EMPLOYEEMANAGER_H

#include <iostream>
#include <stdlib.h>
#include <string.h>

#include "test.h"

using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    system("color 1f");

    testMoney1();

	char a;
	cin>> &a;
    return 0;
}


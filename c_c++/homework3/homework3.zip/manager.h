#ifndef MANAGER_H
#define MANAGER_H

#include "employee.h"

class Manager : public Employee
{
public:
    Manager();
};

#endif // MANAGER_H

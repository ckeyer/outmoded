#include "money.h"

Money::Money()
{
    this->money = 0;
}
Money::Money(double m)
{
    this->money = m;
}
void Money::operator =(double m)
{
    this->money = m;
}
void Money::operator =(Money m)
{
    this->money = m.getMoney();
}
double Money::operator +(double m)
{
    return this->money = m;
}

double Money::operator +(Money m)
{
    return this->money + m.getMoney();
}

double Money::getMoney()
{
    return this->money;
}

Money Money::ValueOf()
{
    Money m( ((int)(this->money*1000)+5)*1.0/1000 );
    return m;
}

char *Money::toString()
{
    double tmp = ((int)(this->money*1000)+5)*1.0/1000;
    char s[20];
    sprintf(s," %.2f",tmp);
    return s;
}

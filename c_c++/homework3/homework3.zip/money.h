#ifndef MONEY_H
#define MONEY_H

#include <stdio.h>

class Money
{
private:
    double money;
public:
    Money();
    Money(double m);
    double getMoney();
    void operator =(double m);
    void operator =(Money m);
    double operator +(double m);
    double operator +(Money m);
    Money ValueOf();
    char *toString();
};

#endif // MONEY_H

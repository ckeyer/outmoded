#include "saler.h"

Saler::Saler()
{
}

#ifndef SALER_H
#define SALER_H

#include "employee.h"

class Saler : public Employee
{
public:
    Saler();
};

#endif // SALER_H

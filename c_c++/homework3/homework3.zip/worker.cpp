#include "worker.h"

Worker::Worker()
{
}

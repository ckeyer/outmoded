#ifndef WORKER_H
#define WORKER_H

#include "employee.h"

class Worker : public Employee
{
public:
    Worker();
};

#endif // WORKER_H

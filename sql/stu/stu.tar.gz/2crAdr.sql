create table tb_addresss
(
	int_address_id int(6),
	chr_address_name varchar(32) CHARACTER SET utf8 COLLATE utf8_bin
)

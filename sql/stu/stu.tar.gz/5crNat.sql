use db_stu;
create table tb_nations
(
	int_nation_id int ,
	int_nation_name char(20) CHARACTER SET utf8 COLLATE utf8_bin
)  

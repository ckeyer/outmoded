insert db_stu.tb_addresss
select 110000,"北京"
union
select 120000,"天津"
union
select 130000,"河北省"
union
select 130100,"石家庄市"
union
select 130700,"张家口市"
union
select 130200,"唐山市"
union
select 130800,"承德市"
union
select 130300,"秦皇岛市"
union
select 130900,"沧州市"
union
select 130400,"邯郸市"
union
select 131000,"廊坊市"
union
select 130500,"邢台市"
union
select 131100,"衡水市"
union
select 130600,"保定市"
union
select 139000,"华北石油教育培训中心"
union
select 140000,"山西省　"
union
select 140100,"太原市"
union
select 140700,"晋中市"
union
select 140200,"大同市"
union
select 140800,"运城市"
union
select 140300,"阳泉市"
union
select 140900,"忻州市"
union
select 140400,"长治市"
union
select 141000,"临汾市"
union
select 140500,"晋城市"
union
select 141100,"吕梁市"
union
select 140600,"朔州市"
union
select 150000,"内蒙古自治区"
union
select 150100,"呼和浩特市"
union
select 150700,"呼伦贝尔市"
union
select 150200,"包头市"
union
select 150800,"巴彦淖尔市"
union
select 150300,"乌海市"
union
select 150900,"乌兰察布市"
union
select 150400,"赤峰市"
union
select 152200,"兴安盟"
union
select 150500,"通辽市"
union
select 152500,"锡林郭勒盟"
union
select 150600,"鄂尔多斯市"
union
select 152900,"阿拉善盟"
union
select 210000,"辽宁省　"
union
select 210100,"沈阳市"
union
select 210800,"营口市"
union
select 210200,"大连市"
union
select 210900,"阜新市"
union
select 210300,"鞍山市"
union
select 211000,"辽阳市"
union
select 210400,"抚顺市"
union
select 211100,"盘锦市"
union
select 210500,"本溪市"
union
select 211200,"铁岭市"
union
select 210600,"丹东市"
union
select 211300,"朝阳市"
union
select 210700,"锦州市"
union
select 211400,"葫芦岛市"
union
select 220000,"吉林省"
union
select 220100,"长春市"
union
select 220600,"白山市"
union
select 220200,"吉林市"
union
select 220700,"松原市"
union
select 220300,"四平市"
union
select 220800,"白城市"
union
select 220400,"辽源市"
union
select 222400,"延边朝鲜族自治州"
union
select 220500,"通化市"
union
select 230000,"黑龙江省"
union
select 230100,"哈尔滨市"
union
select 230800,"佳木斯市"
union
select 230200,"齐齐哈尔市"
union
select 230900,"七台河市"
union
select 230300,"鸡西市"
union
select 231000,"牡丹江市"
union
select 230400,"鹤岗市"
union
select 231100,"黑河市"
union
select 230500,"双鸭山市"
union
select 231200,"绥化市"
union
select 230600,"大庆市"
union
select 232700,"大兴安岭地区"
union
select 230700,"伊春市"
union
select 310000,"上海"
union
select 320000,"江苏省"
union
select 320100,"南京市"
union
select 320800,"淮安市"
union
select 320200,"无锡市"
union
select 320900,"盐城市"
union
select 320300,"徐州市"
union
select 321000,"扬州市"
union
select 320400,"常州市"
union
select 321100,"镇江市"
union
select 320500,"苏州市"
union
select 321200,"泰州市"
union
select 320600,"南通市"
union
select 321300,"宿迁市"
union
select 320700,"连云港市"
union
select 330000,"浙江省"
union
select 330100,"杭州市"
union
select 330700,"金华市"
union
select 330200,"宁波市"
union
select 330800,"衢州市"
union
select 330300,"温州市"
union
select 330900,"舟山市"
union
select 330400,"嘉兴市"
union
select 331000,"台州市"
union
select 330500,"湖州市"
union
select 331100,"丽水市"
union
select 330600,"绍兴市"
union
select 340000,"安徽省"
union
select 340100,"合肥市"
union
select 341100,"滁州市"
union
select 340200,"芜湖市"
union
select 341200,"阜阳市"
union
select 340300,"蚌埠市"
union
select 341300,"宿州市"
union
select 340400,"淮南市"
union
select 341400,"巢湖市"
union
select 340500,"马鞍山市"
union
select 341500,"六安市"
union
select 340600,"淮北市"
union
select 341600,"亳州市"
union
select 340700,"铜陵市"
union
select 341700,"池州市"
union
select 340800,"安庆市"
union
select 341800,"宣城市"
union
select 341000,"黄山市"
union
select 350000,"福建省"
union
select 350100,"福州市"
union
select 350600,"漳州市"
union
select 350200,"厦门市"
union
select 350700,"南平市"
union
select 350300,"莆田市"
union
select 350800,"龙岩市"
union
select 350400,"三明市"
union
select 350900,"宁德市"
union
select 350500,"泉州市"
union
select 360000,"江西省"
union
select 360100,"南昌市"
union
select 360700,"赣州市"
union
select 360200,"景德镇市"
union
select 360800,"吉安市"
union
select 360300,"萍乡市"
union
select 360900,"宜春市"
union
select 360400,"九江市"
union
select 361000,"抚州市"
union
select 360500,"新余市"
union
select 361100,"上饶市"
union
select 360600,"鹰潭市"
union
select 370000,"山东省"
union
select 370100,"济南市"
union
select 371000,"威海市"
union
select 370200,"青岛市"
union
select 371100,"日照市"
union
select 370300,"淄博市"
union
select 371200,"莱芜市"
union
select 370400,"枣庄市"
union
select 371300,"临沂市"
union
select 370500,"东营市"
union
select 371400,"德州市"
union
select 370600,"烟台市"
union
select 371500,"聊城市"
union
select 370700,"潍坊市"
union
select 371600,"滨州市"
union
select 370800,"济宁市"
union
select 371700,"荷泽市"
union
select 370900,"泰安市"
union
select 410000,"河南省　"
union
select 410100,"郑州市"
union
select 411000,"许昌市"
union
select 410200,"开封市"
union
select 411100,"漯河市"
union
select 410300,"洛阳市"
union
select 411200,"三门峡市"
union
select 410400,"平顶山市"
union
select 411300,"南阳市"
union
select 410500,"安阳市"
union
select 411400,"商丘市"
union
select 410600,"鹤壁市"
union
select 411500,"信阳市"
union
select 410700,"新乡市"
union
select 411600,"周口市"
union
select 410800,"焦作市"
union
select 411700,"驻马店市"
union
select 410900,"濮阳市"
union
select 420000,"湖北省"
union
select 420100,"武汉市"
union
select 420900,"孝感市"
union
select 420200,"黄石市"
union
select 421000,"荆州市"
union
select 420300,"十堰市"
union
select 421100,"黄冈市"
union
select 420500,"宜昌市"
union
select 421200,"咸宁市"
union
select 420600,"襄樊市"
union
select 421300,"随州市"
union
select 420700,"鄂州市"
union
select 422800,"恩施土家族苗族自治州"
union
select 420800,"荆门市"
union
select 429000,"省直辖行政单位"
union
select 430000,"湖南省"
union
select 430100,"长沙市"
union
select 430800,"张家界市"
union
select 430200,"株洲市"
union
select 430900,"益阳市"
union
select 430300,"湘潭市"
union
select 431000,"郴州市"
union
select 430400,"衡阳市"
union
select 431100,"永州市"
union
select 430500,"邵阳市"
union
select 431200,"怀化市"
union
select 430600,"岳阳市"
union
select 431300,"娄底市"
union
select 430700,"常德市"
union
select 433100,"湘西土家族苗族自治州"
union
select 440000,"广东省"
union
select 440100,"广州市"
union
select 441400,"梅州市"
union
select 440200,"韶关市"
union
select 441500,"汕尾市"
union
select 440300,"深圳市"
union
select 441600,"河源市"
union
select 440400,"珠海市"
union
select 441700,"阳江市"
union
select 440500,"汕头市"
union
select 441800,"清远市"
union
select 440600,"佛山市"
union
select 441900,"东莞市"
union
select 440700,"江门市"
union
select 442000,"中山市"
union
select 440800,"湛江市"
union
select 445100,"潮州市"
union
select 440900,"茂名市"
union
select 445200,"揭阳市"
union
select 441200,"肇庆市"
union
select 445300,"云浮市"
union
select 441300,"惠州市"
union
select 450000,"广西壮族自治区"
union
select 450100,"南宁市"
union
select 450800,"贵港市"
union
select 450200,"柳州市"
union
select 450900,"玉林市"
union
select 450300,"桂林市"
union
select 451000,"百色市"
union
select 450400,"梧州市"
union
select 451100,"贺州市"
union
select 450500,"北海市"
union
select 451200,"河池市"
union
select 450600,"防城港市"
union
select 451300,"来宾市"
union
select 450700,"钦州市"
union
select 451400,"崇左市"
union
select 460000,"海南省"
union
select 460100,"海口市"
union
select 469000,"省直辖县级行政单位"
union
select 460200,"三亚市"
union
select 500000,"重庆市　"
union
select 510000,"四川省"
union
select 510100,"成都市"
union
select 511400,"眉山市"
union
select 510300,"自贡市"
union
select 511500,"宜宾市"
union
select 510400,"攀枝花市"
union
select 511600,"广安市"
union
select 510500,"泸州市"
union
select 511700,"达州市"
union
select 510600,"德阳市"
union
select 511800,"雅安市"
union
select 510700,"绵阳市"
union
select 511900,"巴中市"
union
select 510800,"广元市"
union
select 512000,"资阳市"
union
select 510900,"遂宁市"
union
select 513200,"阿坝藏族羌族自治州"
union
select 511000,"内江市"
union
select 513300,"甘孜藏族自治州"
union
select 511100,"乐山市"
union
select 513400,"凉山彝族自治州"
union
select 511300,"南充市"
union
select 520000,"贵州省"
union
select 520100,"贵阳市"
union
select 522300,"黔西南布依族苗族自治州"
union
select 520200,"六盘水市"
union
select 522400,"毕节地区"
union
select 520300,"遵义市"
union
select 522600,"黔东南苗族侗族自治州"
union
select 520400,"安顺市"
union
select 522700,"黔南布依族苗族自治州"
union
select 522200,"铜仁地区"
union
select 530000,"云南省"
union
select 530100,"昆明市"
union
select 532300,"楚雄彝族自治州"
union
select 530300,"曲靖市"
union
select 532500,"红河哈尼族彝族自治州"
union
select 530400,"玉溪市"
union
select 532600,"文山壮族苗族自治州"
union
select 530500,"保山市"
union
select 532800,"西双版纳傣族自治州"
union
select 530600,"昭通市"
union
select 532900,"大理白族自治州"
union
select 530700,"丽江市"
union
select 533100,"德宏傣族景颇族自治州"
union
select 530800,"思茅市"
union
select 533300,"怒江傈僳族自治州"
union
select 530900,"临沧市"
union
select 533400,"迪庆藏族自治州"
union
select 540000,"西藏自治区"
union
select 540100,"拉萨市"
union
select 542400,"那曲地区"
union
select 542100,"昌都地区"
union
select 542500,"阿里地区"
union
select 542200,"山南地区"
union
select 542600,"林芝地区"
union
select 542300,"日喀则地区"
union
select 610000,"陕西省"
union
select 610100,"西安市"
union
select 610600,"延安市"
union
select 610200,"铜川市"
union
select 610700,"汉中市"
union
select 610300,"宝鸡市"
union
select 610800,"榆林市"
union
select 610400,"咸阳市"
union
select 610900,"安康市"
union
select 610500,"渭南市"
union
select 611000,"商洛市"
union
select 620000,"甘肃省"
union
select 620100,"兰州市"
union
select 620800,"平凉市"
union
select 620200,"嘉峪关市"
union
select 620900,"酒泉市"
union
select 620300,"金昌市"
union
select 621000,"庆阳市"
union
select 620400,"白银市"
union
select 621100,"定西市"
union
select 620500,"天水市"
union
select 622900,"临夏回族自治州"
union
select 620600,"武威市"
union
select 623000,"甘南藏族自治州"
union
select 620700,"张掖市"
union
select 621200,"陇南市"
union
select 630000,"青海省"
union
select 630100,"西宁市"
union
select 632600,"果洛藏族自治州"
union
select 632100,"海东地区"
union
select 632700,"玉树藏族自治州"
union
select 632200,"海北藏族自治州"
union
select 632800,"海西蒙古族藏族自治州"
union
select 632300,"黄南藏族自治州"
union
select 632900,"青海省油田教育管理中心"
union
select 632500,"海南藏族自治州"
union
select 640000,"宁夏回族自治区"
union
select 640100,"银川市"
union
select 640400,"固原市"
union
select 640200,"石嘴山市"
union
select 640500,"中卫市"
union
select 640300,"吴忠市"
union
select 650000,"新疆维吾尔自治区　"
union
select 650100,"乌鲁木齐市"
union
select 653000,"克孜勒苏柯尔克孜自治州"
union
select 650200,"克拉玛依市"
union
select 653100,"喀什地区"
union
select 652100,"吐鲁番地区"
union
select 653200,"和田地区"
union
select 652200,"哈密地区"
union
select 654000,"伊犁哈萨克自治州"
union
select 652300,"昌吉回族自治州"
union
select 654200,"塔城地区"
union
select 652700,"博尔塔拉蒙古自治州"
union
select 654300,"阿勒泰地区"
union
select 652800,"巴音郭楞蒙古自治州"
union
select 659000,"省直辖行政单位"
union
select 652900,"阿克苏地区"
union
select 660000,"新疆生产建设兵团　"
union
select 660100,"农一师"
union
select 660800,"农八师"
union
select 660200,"农二师"
union
select 660900,"农九师"
union
select 660300,"农三师"
union
select 661000,"农十师"
union
select 660400,"农四师"
union
select 661100,"建工师"
union
select 660500,"农五师"
union
select 661200,"农十二师"
union
select 660600,"农六师"
union
select 661300,"农十三师"
union
select 660700,"农七师"
union
select 661400,"农十四师"
union
select 710000,"台湾省"
union
select 810000,"香港特别行政区"
union
select 820000,"澳门特别行政区"

insert db_stu.tb_class(int_class_id,chr_class_name,int_academy_id,chr_academy_name )
select 41001,"测量1301",1,"城市建设学院"
union
select 41002,"测量1302",1,"城市建设学院"
union
select 41003,"工管1301",1,"城市建设学院"
union
select 41004,"工管1302",1,"城市建设学院"
union
select 41005,"建筑1301",1,"城市建设学院"
union
select 41006,"建筑1302",1,"城市建设学院"
union
select 41007,"建筑1303",1,"城市建设学院"
union
select 41008,"土木1301",1,"城市建设学院"
union
select 41009,"土木1302",1,"城市建设学院"
union
select 41010,"土木1303",1,"城市建设学院"
union
select 41011,"土木1304",1,"城市建设学院"
union
select 41012,"土木1305",1,"城市建设学院"
union
select 41013,"土木1306",1,"城市建设学院"
union
select 41014,"土木1307",1,"城市建设学院"
union
select 41015,"土木1308",1,"城市建设学院"
union
select 41016,"土木1309",1,"城市建设学院"
union
select 41017,"土木1310",1,"城市建设学院"
union
select 41018,"造价1301",1,"城市建设学院"
union
select 41019,"造价1302",1,"城市建设学院"
union
select 41020,"造价1303",1,"城市建设学院"
union
select 41021,"造价1304",1,"城市建设学院"
union
select 41022,"造价1305",1,"城市建设学院"
union
select 41023,"造价1306",1,"城市建设学院"
union
select 41024,"装饰1301",1,"城市建设学院"
union
select 41025,"装饰1302",1,"城市建设学院"
union
select 41026,"装饰1303",1,"城市建设学院"
union
select 41027,"电商1301",2,"商学院"
union
select 41028,"工商1301",2,"商学院"
union
select 41029,"工商1302",2,"商学院"
union
select 41030,"国贸1301",2,"商学院"
union
select 41031,"国贸1302",2,"商学院"
union
select 41032,"会计1301",2,"商学院"
union
select 41033,"会计1302",2,"商学院"
union
select 41034,"会计1303",2,"商学院"
union
select 41035,"会计1304",2,"商学院"
union
select 41036,"会计1305",2,"商学院"
union
select 41037,"会计1306",2,"商学院"
union
select 41038,"会计1307",2,"商学院"
union
select 41039,"会计1308",2,"商学院"
union
select 41040,"人资1301",2,"商学院"
union
select 41041,"投资1301",2,"商学院"
union
select 41042,"物流1301",2,"商学院"
union
select 41043,"营销1301",2,"商学院"
union
select 41044,"高护1301",3,"生命科学学院"
union
select 41045,"高护1302",3,"生命科学学院"
union
select 41046,"高护1303",3,"生命科学学院"
union
select 41047,"高护1304",3,"生命科学学院"
union
select 41048,"高护1305",3,"生命科学学院"
union
select 41049,"高护1306",3,"生命科学学院"
union
select 41050,"高护1307",3,"生命科学学院"
union
select 41051,"高护1308",3,"生命科学学院"
union
select 41052,"高护1309",3,"生命科学学院"
union
select 41053,"高护1310",3,"生命科学学院"
union
select 41054,"护理学1301",3,"生命科学学院"
union
select 41055,"护理学1302",3,"生命科学学院"
union
select 41056,"护理学1303",3,"生命科学学院"
union
select 41057,"护理学1304",3,"生命科学学院"
union
select 41058,"环境工程1301",3,"生命科学学院"
union
select 41059,"生物工程1301",3,"生命科学学院"
union
select 41060,"制药工程1301",3,"生命科学学院"
union
select 41061,"法学1301",4,"文法与外语学院"
union
select 41062,"汉语言文学1301",4,"文法与外语学院"
union
select 41063,"酒店管理1302",4,"文法与外语学院"
union
select 41064,"酒管1301",4,"文法与外语学院"
union
select 41065,"旅游1301",4,"文法与外语学院"
union
select 41066,"日语1301",4,"文法与外语学院"
union
select 41067,"英语1301",4,"文法与外语学院"
union
select 41068,"英语1302",4,"文法与外语学院"
union
select 41069,"英语1303",4,"文法与外语学院"
union
select 41070,"电气1301",5,"信息工程学院"
union
select 41071,"电气1302",5,"信息工程学院"
union
select 41072,"电气1303",5,"信息工程学院"
union
select 41073,"电气1304",5,"信息工程学院"
union
select 41074,"电气1305",5,"信息工程学院"
union
select 41075,"电气1306",5,"信息工程学院"
union
select 41076,"电信1301",5,"信息工程学院"
union
select 41077,"电信1302",5,"信息工程学院"
union
select 41078,"电信1303",5,"信息工程学院"
union
select 41079,"机电1301",5,"信息工程学院"
union
select 41080,"机电1302",5,"信息工程学院"
union
select 41081,"机电1303",5,"信息工程学院"
union
select 41082,"机电1304",5,"信息工程学院"
union
select 41083,"计科1301",5,"信息工程学院"
union
select 41084,"计科1302",5,"信息工程学院"
union
select 41085,"软工1301",5,"信息工程学院"
union
select 41086,"软工1302",5,"信息工程学院"
union
select 41087,"通信1301",5,"信息工程学院"
union
select 41088,"通信1302",5,"信息工程学院"
union
select 41089,"自动化1301",5,"信息工程学院"
union
select 41090,"自动化1302",5,"信息工程学院"
union
select 41091,"产品设计1301",6,"艺术学院"
union
select 41092,"产品设计1302",6,"艺术学院"
union
select 41093,"电脑艺术设计1301",6,"艺术学院"
union
select 41094,"电脑艺术设计1302",6,"艺术学院"
union
select 41095,"电脑艺术设计1303",6,"艺术学院"
union
select 41096,"动画1301",6,"艺术学院"
union
select 41097,"动画1302",6,"艺术学院"
union
select 41098,"广告设计1301",6,"艺术学院"
union
select 41099,"广告设计1302",6,"艺术学院"
union
select 41100,"广告设计1303",6,"艺术学院"
union
select 41101,"环艺1301",6,"艺术学院"
union
select 41102,"环艺1302",6,"艺术学院"
union
select 41103,"环艺1303",6,"艺术学院"
union
select 41104,"环艺1304",6,"艺术学院"
union
select 41105,"环艺1305",6,"艺术学院"
union
select 41106,"视觉传达1301",6,"艺术学院"
union
select 41107,"视觉传达1302",6,"艺术学院"
union
select 41108,"播音1302",6,"艺术学院"
union
select 41109,"播音主持1301",6,"艺术学院"
union
select 41110,"播音主持1303",6,"艺术学院"
union
select 41111,"音表1301",6,"艺术学院"
union
select 41112,"音乐学1301",6,"艺术学院"
union
select 41113,"音乐学1302",6,"艺术学院"
union
select 41114,"音乐学1303",6,"艺术学院"
union
select 41115,"玉雕特色",6,"艺术学院"
union


select 42001,"工程测量1201",1,"城市建设学院"
union
select 42002,"工程测量1202",1,"城市建设学院"
union
select 42003,"工程管理1201",1,"城市建设学院"
union
select 42004,"工程管理1202",1,"城市建设学院"
union
select 42005,"工程造价1201",1,"城市建设学院"
union
select 42006,"工程造价1202",1,"城市建设学院"
union
select 42007,"工程造价1203",1,"城市建设学院"
union
select 42008,"工程造价1204",1,"城市建设学院"
union
select 42009,"建筑学1201",1,"城市建设学院"
union
select 42010,"建筑学1202",1,"城市建设学院"
union
select 42011,"土木1201",1,"城市建设学院"
union
select 42012,"土木1202",1,"城市建设学院"
union
select 42013,"土木1203",1,"城市建设学院"
union
select 42014,"土木1204",1,"城市建设学院"
union
select 42015,"土木1205",1,"城市建设学院"
union
select 42016,"土木1206",1,"城市建设学院"
union
select 42017,"土木工程",1,"城市建设学院"
union
select 42018,"土木工程1207",1,"城市建设学院"
union
select 42019,"土木工程1208",1,"城市建设学院"
union
select 42020,"装饰1201",1,"城市建设学院"
union
select 42021,"装饰1202",1,"城市建设学院"
union
select 42022,"装饰1203",1,"城市建设学院"
union
select 42023,"装饰1204",1,"城市建设学院"
union
select 42024,"工商1201",2,"商学院"
union
select 42025,"工商1202",2,"商学院"
union
select 42026,"工商1203",2,"商学院"
union
select 42027,"工商1204",2,"商学院"
union
select 42028,"国贸1201",2,"商学院"
union
select 42029,"国贸1202",2,"商学院"
union
select 42030,"国商1201",2,"商学院"
union
select 42031,"会计1201",2,"商学院"
union
select 42032,"会计1202",2,"商学院"
union
select 42033,"会计1203",2,"商学院"
union
select 42034,"会计1204",2,"商学院"
union
select 42035,"会计1205",2,"商学院"
union
select 42036,"会计1206",2,"商学院"
union
select 42037,"会计1207",2,"商学院"
union
select 42038,"会计1208",2,"商学院"
union
select 42039,"会计1209",2,"商学院"
union
select 42040,"会计1210",2,"商学院"
union
select 42041,"会计1211",2,"商学院"
union
select 42042,"会计1212",2,"商学院"
union
select 42043,"人资1201",2,"商学院"
union
select 42044,"人资1202",2,"商学院"
union
select 42045,"人资1203",2,"商学院"
union
select 42046,"人资1204",2,"商学院"
union
select 42047,"投资1201",2,"商学院"
union
select 42048,"物流1201",2,"商学院"
union
select 42049,"物流1202",2,"商学院"
union
select 42050,"营销1201",2,"商学院"
union
select 42051,"营销1202",2,"商学院"
union
select 42052,"证券1201",2,"商学院"
union
select 42053,"高护1201",3,"生命科学学院"
union
select 42054,"高护1202",3,"生命科学学院"
union
select 42055,"高护1203",3,"生命科学学院"
union
select 42056,"高护1204",3,"生命科学学院"
union
select 42057,"高护1205",3,"生命科学学院"
union
select 42058,"高护1206",3,"生命科学学院"
union
select 42059,"高护1207",3,"生命科学学院"
union
select 42060,"高护1208",3,"生命科学学院"
union
select 42061,"高护1209",3,"生命科学学院"
union
select 42062,"高护1210",3,"生命科学学院"
union
select 42063,"护理1201",3,"生命科学学院"
union
select 42064,"护理1202",3,"生命科学学院"
union
select 42065,"护理1203",3,"生命科学学院"
union
select 42066,"护理1204",3,"生命科学学院"
union
select 42067,"环工1201",3,"生命科学学院"
union
select 42068,"生工1201",3,"生命科学学院"
union
select 42069,"制药1201",3,"生命科学学院"
union
select 42070,"法学1201",4,"文法与外语学院"
union
select 42071,"法学1202",4,"文法与外语学院"
union
select 42072,"汉语言文学1201",4,"文法与外语学院"
union
select 42073,"行管1201",4,"文法与外语学院"
union
select 42074,"酒管1201",4,"文法与外语学院"
union
select 42075,"酒管1202",4,"文法与外语学院"
union
select 42076,"旅游1201",4,"文法与外语学院"
union
select 42077,"日语1201",4,"文法与外语学院"
union
select 42078,"英语1201",4,"文法与外语学院"
union
select 42079,"英语1202",4,"文法与外语学院"
union
select 42080,"英语1203",4,"文法与外语学院"
union
select 42081,"电气1201",5,"信息工程学院"
union
select 42082,"电气1202",5,"信息工程学院"
union
select 42083,"电气1203",5,"信息工程学院"
union
select 42084,"电气1204",5,"信息工程学院"
union
select 42085,"电信1201",5,"信息工程学院"
union
select 42086,"电信1202",5,"信息工程学院"
union
select 42087,"机电1201",5,"信息工程学院"
union
select 42088,"机电1202",5,"信息工程学院"
union
select 42089,"机电1203",5,"信息工程学院"
union
select 42090,"计科1201",5,"信息工程学院"
union
select 42091,"计网1201",5,"信息工程学院"
union
select 42092,"软工1201",5,"信息工程学院"
union
select 42093,"通信1201",5,"信息工程学院"
union
select 42094,"通信1202",5,"信息工程学院"
union
select 42095,"自动化1201",5,"信息工程学院"
union
select 42096,"自动化1202",5,"信息工程学院"
union
select 42097,"电艺1201",6,"艺术学院"
union
select 42098,"电艺1202",6,"艺术学院"
union
select 42099,"电艺1203",6,"艺术学院"
union
select 42100,"动画1201",6,"艺术学院"
union
select 42101,"动画1202",6,"艺术学院"
union
select 42102,"广告1201",6,"艺术学院"
union
select 42103,"广告1202",6,"艺术学院"
union
select 42104,"艺术1201",6,"艺术学院"
union
select 42105,"艺术1202",6,"艺术学院"
union
select 42106,"艺术1203",6,"艺术学院"
union
select 42107,"艺术1204",6,"艺术学院"
union
select 42108,"艺术1205",6,"艺术学院"
union
select 42109,"艺术1206",6,"艺术学院"
union
select 42110,"艺术1207",6,"艺术学院"
union
select 42111,"艺术1208",6,"艺术学院"
union
select 42112,"艺术设计1209",6,"艺术学院"
union
select 42113,"音乐表演1201",6,"艺术学院"
union
select 42114,"音乐表演1202",6,"艺术学院"
union
select 42115,"音乐学1201",6,"艺术学院"
union
select 42116,"音乐学1202",6,"艺术学院"

insert db_stu.tb_nations
select 1,"汉族"
union
select 2,"蒙古族"
union
select 3,"回族"
union
select 4,"藏族"
union
select 5,"维吾尔族"
union
select 6,"苗族"
union
select 7,"彝族"
union
select 8,"壮族"
union
select 9,"布依族"
union
select 10,"朝鲜族"
union
select 11,"满族"
union
select 12,"侗族"
union
select 13,"瑶族"
union
select 14,"白族"
union
select 15,"土家族"
union
select 16,"哈尼族"
union
select 17,"哈萨克族"
union
select 18,"傣族"
union
select 19,"黎族"
union
select 20,"傈僳族"
union
select 21,"佤族"
union
select 22,"畲族"
union
select 23,"高山族"
union
select 24,"拉祜族"
union
select 25,"水族"
union
select 26,"东乡族"
union
select 27,"纳西族"
union
select 28,"景颇族"
union
select 29,"柯尔克孜族"
union
select 30,"土族"
union
select 31,"达斡尔族"
union
select 32,"仫佬族"
union
select 33,"羌族"
union
select 34,"布朗族"
union
select 35,"撒拉族"
union
select 36,"毛南族"
union
select 37,"仡佬族"
union
select 38,"锡伯族"
union
select 39,"阿昌族"
union
select 40,"普米族"
union
select 41,"塔吉克族"
union
select 42,"怒族"
union
select 43,"乌孜别克族"
union
select 44,"俄罗斯族"
union
select 45,"鄂温克族"
union
select 46,"德昂族"
union
select 47,"保安族"
union
select 48,"裕固族"
union
select 49,"京族"
union
select 50,"塔塔尔族"
union
select 51,"独龙族"
union
select 52,"鄂伦春族"
union
select 53,"赫哲族"
union
select 54,"门巴族"
union
select 55,"珞巴族"
union
select 56,"基诺族"
union
select 57,"其他"
union
select 58,"外国血统"
